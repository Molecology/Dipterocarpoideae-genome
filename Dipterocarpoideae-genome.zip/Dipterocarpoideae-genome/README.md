# Dipterocarpoideae-genome

Phylogenomic analysis: code1, code2;
Whole genome duplication: code3, code4;
Comparative genomics: code5;
Variant calling: code11;
Population genomics: code6, code7, code8, code9, code10, code12.



