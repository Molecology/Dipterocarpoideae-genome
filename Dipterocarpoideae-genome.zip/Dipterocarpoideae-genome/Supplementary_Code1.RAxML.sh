###The input file is given as 'single-copy.pep.phy'.
raxmlHPC-PTHREADS -s single-copy.pep.phy  -n pep -m PROTGAMMAAUTO -p 12345 -x 12345 -# 100 -f ad -T 30 -o Grai,Tcac
